var slika1 = document.getElementsByClassName('krugovi')[0];
var slika2 = document.getElementsByClassName('krugovi')[1];
var slika3 = document.getElementsByClassName('krugovi')[2];

slika1.addEventListener('mouseover', promeni1, false);
slika1.addEventListener('mouseout', vrati1, false);
slika2.addEventListener('mouseover', promeni2, false);
slika2.addEventListener('mouseout', vrati2, false);
slika3.addEventListener('mouseover', promeni3, false);
slika3.addEventListener('mouseout', vrati3, false);

function promeni1(e) {
  slika1.src = 'slike/slika1.jpg';
}

function vrati1(e) {
  slika1.src = 'slike/back1.jpg';
}

function promeni2(e) {
  slika2.src = 'slike/slika2.jpg';
}

function vrati2(e) {
  slika2.src = 'slike/back2.jpg';
}

function promeni3(e) {
  slika3.src = 'slike/slika3.jpg';
}

function vrati3(e) {
  slika3.src = 'slike/back3.jpg';
}


var interior1 = document.getElementsByClassName('krugovi')[3];
var interior2 = document.getElementsByClassName('krugovi')[4];
var interior3 = document.getElementsByClassName('krugovi')[5];

interior1.addEventListener('mouseover', promeni11, false);
interior1.addEventListener('mouseout', vrati11, false);
interior2.addEventListener('mouseover', promeni22, false);
interior2.addEventListener('mouseout', vrati22, false);
interior3.addEventListener('mouseover', promeni33, false);
interior3.addEventListener('mouseout', vrati33, false);

function promeni11(e) {
  interior1.src = 'slike/interior1.jpg';
}

function vrati11(e) {
  interior1.src = 'slike/slika1.jpg';
}

function promeni22(e) {
  interior2.src = 'slike/interior2.jpg';
}

function vrati22(e) {
  interior2.src = 'slike/slika2.jpg';
}

function promeni33(e) {
  interior3.src = 'slike/interior3.jpg';
}

function vrati33(e) {
  interior3.src = 'slike/slika3.jpg';
}
